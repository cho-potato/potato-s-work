package db.diary;

public class UseCat {
	public static void main(String[] args) {
		Cat cat=Cat.getInstence();
		System.out.println(cat);

	}
}
