package Test;

import javax.swing.JFrame;

public class Test extends JFrame{

}
