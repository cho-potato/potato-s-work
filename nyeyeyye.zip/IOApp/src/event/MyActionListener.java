
/* 1. 귀가 외부에 있는 */
// .java로 뺴내서 서로 주소를 주고받아야하는 불편함이 생김

package event;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MyActionListener implements ActionListener{

	public void actionPerformed(ActionEvent e) {
		System.out.println("?ADQ$YYRTH");
	}
}
